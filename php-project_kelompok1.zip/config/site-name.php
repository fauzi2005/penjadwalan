<?php 
$siteName = "SMKN 19 Jakarta";
?>