<!-- jQuery -->
	<script src="<?= BASE_URL ?>assets/plugins/jquery/jquery.min.js"></script>
	<!-- jQuery UI 1.11.4 -->
	<script src="<?= BASE_URL ?>assets/plugins/jquery-ui/jquery-ui.min.js"></script>
	<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
	<script>
		$.widget.bridge('uibutton', $.ui.button)
	</script>
	<!-- Bootstrap 4 -->
	<script src="<?= BASE_URL ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
	<!-- SweetAlert2 -->
	<script src="<?= BASE_URL ?>assets/plugins/sweetalert2/sweetalert2.min.js"></script>
	<!-- Toastr -->
	<script src="<?= BASE_URL ?>assets/plugins/toastr/toastr.min.js"></script>
	<!-- daterangepicker -->
	<script src="<?= BASE_URL ?>assets/plugins/moment/moment.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/daterangepicker/daterangepicker.js"></script>
	<!-- overlayScrollbars -->
	<script src="<?= BASE_URL ?>assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
	<!-- AdminLTE App -->
	<script src="<?= BASE_URL ?>assets/js/adminlte.js"></script>
	<!-- DataTables  & Plugins -->
	<script src="<?= BASE_URL ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/jszip/jszip.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/pdfmake/pdfmake.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/pdfmake/vfs_fonts.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-buttons/js/buttons.print.min.js"></script>
	<script src="<?= BASE_URL ?>assets/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>