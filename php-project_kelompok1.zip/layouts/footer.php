<footer class="main-footer">
	<strong>Copyright &copy; 2022 <a href="">Kelompok 1 Unindra S6I</a>.</strong>
	All rights reserved.
	<div class="float-right d-none d-sm-inline-block">
		<b>AdminLTE Version</b> 3.2.0
	</div>
</footer>